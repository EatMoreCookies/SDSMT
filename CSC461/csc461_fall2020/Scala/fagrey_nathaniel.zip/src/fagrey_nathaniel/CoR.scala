package fagrey_nathaniel

trait CoR {
  def findFood(foodName: String): Boolean
}
