package fagrey_nathaniel;

public interface Observer {
    void update();
}
