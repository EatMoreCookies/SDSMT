package fagrey_nathaniel;

public class Penthouse extends Apartment {
    Penthouse(){
        this.rent = 2000;
        this.name = "Penthouse";
        this.maintenence = 1000;
        this.remodel = 10000;
    }
}
