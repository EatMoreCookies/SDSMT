package fagrey_nathaniel;

public class Basic extends Apartment{
    Basic(){
        this.rent = 800;
        this.name = "Basic";
        this.maintenence = 450;
        this.remodel = 4000;
    }
}
